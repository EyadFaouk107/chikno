import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { reviews } from "@db/schema";
import { desc } from "drizzle-orm";

export const contactRouter = createRouter({
  submitReview: publicQuery
    .input(
      z.object({
        customerName: z.string().min(1).max(255),
        rating: z.number().min(1).max(5).default(5),
        comment: z.string().min(1).max(1000),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.insert(reviews).values({
        customerName: input.customerName,
        rating: input.rating,
        comment: input.comment,
      });
      return { success: true };
    }),

  reviews: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(reviews).orderBy(desc(reviews.createdAt)).limit(20);
  }),
});
