import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { orders, orderItems } from "@db/schema";
import { eq } from "drizzle-orm";

export const orderRouter = createRouter({
  create: publicQuery
    .input(
      z.object({
        customerName: z.string().min(1),
        customerPhone: z.string().min(1),
        customerAddress: z.string().optional(),
        orderType: z.enum(["delivery", "pickup"]).default("delivery"),
        items: z.array(
          z.object({
            menuItemId: z.number(),
            name: z.string(),
            quantity: z.number().min(1),
            price: z.number(),
            size: z.string().optional(),
          })
        ),
        subtotal: z.number(),
        deliveryFee: z.number().default(0),
        total: z.number(),
        notes: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const orderNumber = `CHK${Date.now().toString(36).toUpperCase()}`;

      const result = await db.insert(orders).values({
        orderNumber,
        customerName: input.customerName,
        customerPhone: input.customerPhone,
        customerAddress: input.customerAddress,
        orderType: input.orderType,
        status: "received",
        subtotal: input.subtotal.toString(),
        deliveryFee: input.deliveryFee.toString(),
        total: input.total.toString(),
        notes: input.notes,
      });

      const orderId = Number(result[0].insertId);

      for (const item of input.items) {
        await db.insert(orderItems).values({
          orderId,
          menuItemId: item.menuItemId,
          name: item.name,
          quantity: item.quantity,
          price: item.price.toString(),
          size: item.size,
        });
      }

      return { success: true, orderId, orderNumber };
    }),

  track: publicQuery
    .input(z.object({ orderNumber: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      const orderList = await db
        .select()
        .from(orders)
        .where(eq(orders.orderNumber, input.orderNumber))
        .limit(1);

      if (orderList.length === 0) return null;

      const order = orderList[0];
      const items = await db
        .select()
        .from(orderItems)
        .where(eq(orderItems.orderId, order.id));

      return { ...order, items };
    }),

  updateStatus: publicQuery
    .input(
      z.object({
        orderNumber: z.string(),
        status: z.enum(["received", "preparing", "cooking", "ontheway", "delivered", "cancelled"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(orders)
        .set({ status: input.status, updatedAt: new Date() })
        .where(eq(orders.orderNumber, input.orderNumber));
      return { success: true };
    }),
});
