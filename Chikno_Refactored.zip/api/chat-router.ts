import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { chatMessages } from "@db/schema";
import { eq, asc, desc } from "drizzle-orm";
import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic();

const SYSTEM_PROMPT = `You are a helpful assistant for Chikno, an Egyptian chicken restaurant. Help customers with menu questions, pricing, ordering, branch locations, and the loyalty program. Be friendly and concise. Key info: main branch at 279 Al-Matbaa Station St, Faisal, Giza. Hours: Sun-Thu 12pm-12am, Fri-Sat 1pm-1am. Phone: 01019911122.`;

export const chatRouter = createRouter({
  history: publicQuery
    .input(z.object({ sessionId: z.string() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db
        .select()
        .from(chatMessages)
        .where(eq(chatMessages.sessionId, input.sessionId))
        .orderBy(asc(chatMessages.createdAt))
        .limit(50);
    }),

  send: publicQuery
    .input(
      z.object({
        sessionId: z.string(),
        message: z.string().min(1).max(2000),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();

      // Store user message
      await db.insert(chatMessages).values({
        sessionId: input.sessionId,
        role: "user",
        content: input.message,
      });

      // Get last 10 messages for conversation history
      const history = await db
        .select()
        .from(chatMessages)
        .where(eq(chatMessages.sessionId, input.sessionId))
        .orderBy(desc(chatMessages.createdAt))
        .limit(10);

      // Reverse to get chronological order
      const conversationHistory = history.reverse().map((msg) => ({
        role: msg.role as "user" | "assistant",
        content: msg.content,
      }));

      // Call Anthropic API
      const response = await client.messages.create({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1024,
        system: SYSTEM_PROMPT,
        messages: conversationHistory,
      });

      const assistantMessage = response.content[0].type === "text" ? response.content[0].text : "";

      // Store assistant response
      await db.insert(chatMessages).values({
        sessionId: input.sessionId,
        role: "assistant",
        content: assistantMessage,
      });

      return { response: assistantMessage };
    }),
});
