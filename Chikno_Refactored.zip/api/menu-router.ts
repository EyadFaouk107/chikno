import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { menuItems, categories } from "@db/schema";
import { eq, asc } from "drizzle-orm";

export const menuRouter = createRouter({
  categories: publicQuery.query(async () => {
    const db = getDb();
    return db.select().from(categories).orderBy(asc(categories.sortOrder));
  }),

  items: publicQuery
    .input(
      z.object({
        categoryId: z.number().optional(),
        search: z.string().optional(),
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.categoryId) {
        return db
          .select()
          .from(menuItems)
          .where(eq(menuItems.categoryId, input.categoryId))
          .orderBy(asc(menuItems.sortOrder));
      }
      return db.select().from(menuItems).orderBy(asc(menuItems.sortOrder));
    }),

  itemById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const items = await db
        .select()
        .from(menuItems)
        .where(eq(menuItems.id, input.id))
        .limit(1);
      return items[0] || null;
    }),
});
