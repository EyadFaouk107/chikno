import { authRouter } from "./auth-router";
import { localAuthRouter } from "./local-auth-router";
import { menuRouter } from "./menu-router";
import { cartRouter } from "./cart-router";
import { orderRouter } from "./order-router";
import { chatRouter } from "./chat-router";
import { contactRouter } from "./contact-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  localAuth: localAuthRouter,
  menu: menuRouter,
  cart: cartRouter,
  order: orderRouter,
  chat: chatRouter,
  contact: contactRouter,
});

export type AppRouter = typeof appRouter;
