import { z } from "zod";
import { TRPCError } from "@trpc/server";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { localUsers } from "@db/schema";
import { eq } from "drizzle-orm";

const LOCAL_AUTH_SECRET = process.env.LOCAL_AUTH_SECRET || "chikno-local-auth-secret-key-2026";

export const localAuthRouter = createRouter({
  register: publicQuery
    .input(
      z.object({
        username: z.string().min(3).max(100),
        password: z.string().min(6).max(100),
        displayName: z.string().min(1).max(255).optional(),
        email: z.string().email().optional(),
        phone: z.string().max(20).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const existing = await db.select().from(localUsers).where(eq(localUsers.username, input.username)).limit(1);
      if (existing.length > 0) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "Username already exists",
        });
      }

      const passwordHash = await bcrypt.hash(input.password, 10);
      const result = await db.insert(localUsers).values({
        username: input.username,
        passwordHash,
        displayName: input.displayName || input.username,
        email: input.email,
        phone: input.phone,
      });

      const user = await db.select().from(localUsers).where(eq(localUsers.id, Number(result[0].insertId))).limit(1);
      const token = jwt.sign(
        { userId: user[0].id, username: user[0].username, role: user[0].role },
        LOCAL_AUTH_SECRET,
        { expiresIn: "30d" }
      );

      return {
        token,
        user: {
          id: user[0].id,
          username: user[0].username,
          name: user[0].displayName || user[0].username,
          email: user[0].email,
          role: user[0].role,
          loyaltyPoints: user[0].loyaltyPoints,
          loyaltyTier: user[0].loyaltyTier,
        },
      };
    }),

  login: publicQuery
    .input(
      z.object({
        username: z.string().min(1),
        password: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const users = await db.select().from(localUsers).where(eq(localUsers.username, input.username)).limit(1);
      if (users.length === 0) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid username or password",
        });
      }

      const user = users[0];
      const valid = await bcrypt.compare(input.password, user.passwordHash);
      if (!valid) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "Invalid username or password",
        });
      }

      const token = jwt.sign(
        { userId: user.id, username: user.username, role: user.role },
        LOCAL_AUTH_SECRET,
        { expiresIn: "30d" }
      );

      return {
        token,
        user: {
          id: user.id,
          username: user.username,
          name: user.displayName || user.username,
          email: user.email,
          role: user.role,
          loyaltyPoints: user.loyaltyPoints,
          loyaltyTier: user.loyaltyTier,
        },
      };
    }),

  me: publicQuery.query(async ({ ctx }) => {
    const authHeader = ctx.req.headers.get("x-local-auth-token");
    if (!authHeader) {
      return null;
    }

    try {
      const decoded = jwt.verify(authHeader, LOCAL_AUTH_SECRET) as {
        userId: number;
        username: string;
        role: string;
      };

      const db = getDb();
      const users = await db
        .select()
        .from(localUsers)
        .where(eq(localUsers.id, decoded.userId))
        .limit(1);

      if (users.length === 0) return null;

      const user = users[0];
      return {
        id: user.id,
        username: user.username,
        name: user.displayName || user.username,
        email: user.email,
        role: user.role,
        loyaltyPoints: user.loyaltyPoints,
        loyaltyTier: user.loyaltyTier,
      };
    } catch {
      return null;
    }
  }),
});
