import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router";
import { Menu, X, ShoppingCart, MessageCircle, User } from "lucide-react";
import { useCartStore } from "@/hooks/useCartStore";
import { useCartDrawerStore } from "@/hooks/useCartDrawerStore";
import MobileNavDrawer from "./MobileNavDrawer";

const navLinks = [
  { label: "Menu", href: "/menu" },
  { label: "Branches", href: "/branches" },
  { label: "Loyalty", href: "/loyalty" },
  { label: "Contact", href: "/contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const cartCount = useCartStore((s) => s.getCount());
  const { toggle: toggleCart } = useCartDrawerStore();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? "bg-brand-bg/95 backdrop-blur-xl border-b border-white/5"
            : "bg-transparent"
        }`}
      >
        <div className="w-full px-6 lg:px-12 h-16 flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <span className="text-2xl font-black tracking-tighter text-white font-display">
              CHIKNO
            </span>
            <span className="hidden sm:inline-block w-2 h-2 rounded-full bg-brand-accent" />
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                to={link.href}
                className={`text-sm font-medium tracking-wide uppercase transition-colors hover:text-brand-accent ${
                  location.pathname === link.href ? "text-brand-accent" : "text-white/70"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-3">
            <Link
              to="/chat"
              className="hidden md:flex w-9 h-9 items-center justify-center rounded-full bg-white/5 hover:bg-brand-accent/20 transition-colors"
              aria-label="AI Assistant"
            >
              <MessageCircle className="w-4 h-4 text-brand-accent" />
            </Link>

            <button
              onClick={toggleCart}
              className="relative w-9 h-9 flex items-center justify-center rounded-full bg-white/5 hover:bg-brand-accent/20 transition-colors"
              aria-label="Shopping cart"
            >
              <ShoppingCart className="w-4 h-4 text-white" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center rounded-full bg-brand-accent text-[10px] font-bold text-black">
                  {cartCount}
                </span>
              )}
            </button>

            <Link
              to="/login"
              className="hidden md:flex w-9 h-9 items-center justify-center rounded-full bg-white/5 hover:bg-brand-accent/20 transition-colors"
              aria-label="User account"
            >
              <User className="w-4 h-4 text-white" />
            </Link>

            <Link
              to="/menu"
              className="hidden md:inline-flex items-center gap-2 px-5 py-2 rounded-full bg-brand-accent text-black text-sm font-bold uppercase tracking-wide hover:scale-105 transition-transform"
            >
              Order Now
            </Link>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden w-9 h-9 flex items-center justify-center"
              aria-label="Toggle mobile menu"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </nav>

      <MobileNavDrawer isOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
    </>
  );
}
