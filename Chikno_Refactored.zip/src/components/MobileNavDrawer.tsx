import { X, MessageCircle } from "lucide-react";
import { Link } from "react-router";

const navLinks = [
  { label: "Menu", href: "/menu" },
  { label: "Branches", href: "/branches" },
  { label: "Loyalty", href: "/loyalty" },
  { label: "Contact", href: "/contact" },
];

interface MobileNavDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileNavDrawer({ isOpen, onClose }: MobileNavDrawerProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-40 md:hidden">
      <div
        className="absolute inset-0 bg-black/60"
        onClick={onClose}
        role="dialog"
        aria-modal="true"
      />
      <div className="absolute right-0 top-0 bottom-0 w-72 bg-brand-bg border-l border-white/10 p-6 pt-20">
        <div className="flex flex-col gap-4">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className="text-lg font-semibold text-white/80 hover:text-brand-accent transition-colors py-2 border-b border-white/5"
            >
              {link.label}
            </Link>
          ))}
          <Link
            to="/chat"
            className="text-lg font-semibold text-white/80 hover:text-brand-accent transition-colors py-2 border-b border-white/5 flex items-center gap-2"
          >
            <MessageCircle className="w-5 h-5" /> AI Assistant
          </Link>
          <Link
            to="/menu"
            className="mt-4 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-brand-accent text-black text-sm font-bold uppercase tracking-wide"
          >
            Order Now
          </Link>
        </div>
      </div>
    </div>
  );
}
