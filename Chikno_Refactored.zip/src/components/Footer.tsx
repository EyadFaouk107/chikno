import { Link } from "react-router";
import { MapPin, Phone, Instagram, Facebook } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-brand-bg border-t border-white/5">
      <div className="w-full px-6 lg:px-12 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="space-y-4">
            <h3 className="text-2xl font-black tracking-tighter font-display">
              CHIKNO
            </h3>
            <p className="text-sm text-white/50 leading-relaxed">
              Fresh daily. Bold flavor. No compromises. Egypt's favorite chicken restaurant since day one.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://www.facebook.com/ChiknoEgypt"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-accent/20 transition-colors"
                aria-label="Visit Chikno on Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://www.instagram.com/ChiknoEgypt"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-brand-accent/20 transition-colors"
                aria-label="Visit Chikno on Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-widest text-white/40">Quick Links</h4>
            <div className="flex flex-col gap-2">
              <Link to="/menu" className="text-sm text-white/60 hover:text-brand-accent transition-colors">Menu</Link>
              <Link to="/branches" className="text-sm text-white/60 hover:text-brand-accent transition-colors">Branches</Link>
              <Link to="/loyalty" className="text-sm text-white/60 hover:text-brand-accent transition-colors">Rewards</Link>
              <Link to="/contact" className="text-sm text-white/60 hover:text-brand-accent transition-colors">Contact</Link>
              <Link to="/chat" className="text-sm text-white/60 hover:text-brand-accent transition-colors">AI Assistant</Link>
            </div>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-widest text-white/40">Contact</h4>
            <div className="flex flex-col gap-3">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-brand-accent mt-0.5 shrink-0" />
                <span className="text-sm text-white/60">279 Al-Matbaa Station St, Faisal, Giza</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-brand-accent shrink-0" />
                <a href="tel:+201019911122" className="text-sm text-white/60 hover:text-brand-accent transition-colors">01019911122</a>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-brand-accent shrink-0" />
                <a href="tel:+201117655537" className="text-sm text-white/60 hover:text-brand-accent transition-colors">01117655537</a>
              </div>
              <a
                href="https://wa.me/201117655537?text=Hello%20Chikno!"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-600/20 text-green-400 text-sm font-semibold hover:bg-green-600/30 transition-colors w-fit"
              >
                <Phone className="w-4 h-4" /> Order via WhatsApp
              </a>
            </div>
          </div>

          {/* Hours */}
          <div className="space-y-4">
            <h4 className="text-sm font-bold uppercase tracking-widest text-white/40">Hours</h4>
            <div className="flex flex-col gap-2">
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Sun - Thu</span>
                <span className="text-white/80">12pm - 12am</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Fri - Sat</span>
                <span className="text-white/80">1pm - 1am</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/30">© 2026 Chikno. All rights reserved.</p>
          <div className="flex items-center gap-4 text-xs text-white/30">
            <span>Privacy</span>
            <span>Terms</span>
            <span>Careers</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
