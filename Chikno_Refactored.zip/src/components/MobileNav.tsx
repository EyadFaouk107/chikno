import { Link, useLocation } from "react-router";
import { Home, UtensilsCrossed, Flame, ShoppingCart, User } from "lucide-react";
import { useCartStore } from "@/hooks/useCartStore";

const navItems = [
  { icon: Home, label: "Home", href: "/" },
  { icon: UtensilsCrossed, label: "Menu", href: "/menu" },
  { icon: Flame, label: "Offers", href: "/menu?filter=popular" },
  { icon: ShoppingCart, label: "Cart", href: "#" },
  { icon: User, label: "Account", href: "/login" },
];

export default function MobileNav() {
  const location = useLocation();
  const cartCount = useCartStore((s) => s.getCount());

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0B0C0F]/95 backdrop-blur-xl border-t border-white/5">
      <div className="flex items-center justify-around h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.href;

          if (item.label === "Cart") {
            return (
              <button
                key={item.label}
                onClick={() => {
                  const cartBtn = document.querySelector('[data-cart-trigger]') as HTMLButtonElement;
                  cartBtn?.click();
                }}
                className="flex flex-col items-center gap-1 relative"
              >
                <div className="relative">
                  <Icon className={`w-5 h-5 ${isActive ? "text-[#BFFF00]" : "text-white/50"}`} />
                  {cartCount > 0 && (
                    <span className="absolute -top-1.5 -right-2 w-4 h-4 flex items-center justify-center rounded-full bg-[#BFFF00] text-[9px] font-bold text-black">
                      {cartCount}
                    </span>
                  )}
                </div>
                <span className={`text-[10px] ${isActive ? "text-[#BFFF00]" : "text-white/50"}`}>
                  {item.label}
                </span>
              </button>
            );
          }

          return (
            <Link
              key={item.label}
              to={item.href}
              className="flex flex-col items-center gap-1"
            >
              <Icon className={`w-5 h-5 ${isActive ? "text-[#BFFF00]" : "text-white/50"}`} />
              <span className={`text-[10px] ${isActive ? "text-[#BFFF00]" : "text-white/50"}`}>
                {item.label}
              </span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
