export default function PageLoader() {
  return (
    <div className="h-screen flex items-center justify-center">
      <div className="animate-spin w-8 h-8 border-2 border-lime-400 border-t-transparent rounded-full" />
    </div>
  )
}
