import { X, ShoppingCart } from "lucide-react";
import { Link } from "react-router";
import { useCartStore } from "@/hooks/useCartStore";
import { useCartDrawerStore } from "@/hooks/useCartDrawerStore";

export default function CartDrawer() {
  const { isOpen, close } = useCartDrawerStore();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60]">
      <div
        className="absolute inset-0 bg-black/60"
        onClick={close}
        role="dialog"
        aria-modal="true"
      />
      <div className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-[#0B0C0F] border-l border-white/10 flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-white/10">
          <h2 className="text-xl font-bold">Your Cart</h2>
          <button onClick={close} aria-label="Close cart">
            <X className="w-5 h-5" />
          </button>
        </div>
        <CartPanel onClose={close} />
      </div>
    </div>
  );
}

function CartPanel({ onClose }: { onClose: () => void }) {
  const { items, removeItem, updateQuantity, getTotal, clearCart } = useCartStore();
  const total = getTotal();

  return (
    <>
      <div className="flex-1 overflow-auto p-6">
        {items.length === 0 ? (
          <div className="text-center py-12 text-white/40">
            <ShoppingCart className="w-12 h-12 mx-auto mb-4 opacity-30" />
            <p>Your cart is empty</p>
            <Link
              to="/menu"
              onClick={onClose}
              className="inline-block mt-4 text-[#BFFF00] hover:underline"
            >
              Browse Menu
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {items.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-4 p-3 rounded-xl bg-white/5 border border-white/5"
              >
                <div className="flex-1">
                  <p className="font-semibold text-sm">
                    <span lang="ar">{item.nameAr}</span>
                  </p>
                  <p className="text-xs text-white/50">{item.name}</p>
                  {item.size && (
                    <p className="text-xs text-[#BFFF00]">Size: {item.size}</p>
                  )}
                  <p className="text-sm font-bold mt-1">{item.price} LE</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center text-sm hover:bg-[#BFFF00]/20"
                    aria-label="Decrease quantity"
                  >
                    -
                  </button>
                  <span className="text-sm font-bold w-6 text-center">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center text-sm hover:bg-[#BFFF00]/20"
                    aria-label="Increase quantity"
                  >
                    +
                  </button>
                </div>
                <button
                  onClick={() => removeItem(item.id)}
                  className="w-7 h-7 rounded-full bg-red-500/20 flex items-center justify-center hover:bg-red-500/40"
                  aria-label="Remove item"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
      {items.length > 0 && (
        <div className="p-6 border-t border-white/10 space-y-4">
          <div className="flex justify-between text-sm">
            <span className="text-white/60">Subtotal</span>
            <span className="font-bold">{total.toFixed(2)} LE</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-white/60">Delivery</span>
            <span className="font-bold text-[#BFFF00]">Free</span>
          </div>
          <div className="flex justify-between text-lg font-bold border-t border-white/10 pt-3">
            <span>Total</span>
            <span>{total.toFixed(2)} LE</span>
          </div>
          <Link
            to="/menu"
            onClick={onClose}
            className="block w-full py-3 rounded-full bg-[#BFFF00] text-black text-center font-bold uppercase tracking-wide hover:scale-[1.02] transition-transform"
          >
            Checkout
          </Link>
          <button
            onClick={clearCart}
            className="block w-full py-2 text-center text-sm text-white/40 hover:text-white/60 transition-colors"
          >
            Clear Cart
          </button>
        </div>
      )}
    </>
  );
}
