import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import {
  Flame, MapPin, Clock, Star, ChevronRight,
  UtensilsCrossed, Truck, Award, MessageCircle
} from "lucide-react";
import { useCartStore } from "@/hooks/useCartStore";
import { trpc } from "@/providers/trpc";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

gsap.registerPlugin(ScrollTrigger);

const reviews = [
  { name: "Mohamed A.", text: "The crispy is unreal, best thing I've ever eaten", rating: 5 },
  { name: "Sarah M.", text: "The Jalapeno Shawarma is fire! Chikno never disappoints", rating: 5 },
  { name: "Khaled E.", text: "Barkeh Box feeds 4 people, amazing value for money", rating: 5 },
  { name: "Noor T.", text: "The fateh arrives hot and tastes incredible", rating: 4 },
  { name: "Ahmed S.", text: "Chikno Pizza rivals the biggest brands", rating: 5 },
];

const catIcons: Record<string, string> = {
  "Fried Chicken": "🍗",
  "Grilled": "🔥",
  "Shawarma": "🌯",
  "Burgers & Sandwiches": "🍔",
  "Pizza": "🍕",
  "Boxes": "📦",
  "Fateh": "🍲",
  "Appetizers": "🥗",
  "Kids Meal": "👦",
  "Sweets": "🍮",
  "Drinks": "🥤",
  "Grilled Meat": "🥩",
};

// Fallback data for loading skeletons
const skeletonBestSellers = [
  { nameAr: "كريسبي", nameEn: "Crispy", price: 32, mealPrice: 55, cat: "Sandwiches", img: "/images/chicken-sandwich.jpg", spicy: 1 },
  { nameAr: "فراخ بروستد ٣ قطع", nameEn: "3pc Broasted Chicken", price: 130, cat: "Fried Chicken", img: "/images/fried-basket.jpg", spicy: 0 },
  { nameAr: "فتة شاورما فراخ", nameEn: "Chicken Shawarma Fateh", price: 85, cat: "Fateh", img: "/images/chicken-plate.jpg", spicy: 0 },
  { nameAr: "بيتزا تشيكنو (M)", nameEn: "Chikno Pizza (M)", price: 135, cat: "Pizza", img: "/images/hero-kitchen.jpg", spicy: 0 },
  { nameAr: "شاورما فرنساوي", nameEn: "French Shawarma", price: 53, cat: "Shawarma", img: "/images/grilled-skewers.jpg", spicy: 1 },
  { nameAr: "Kids Meal", nameEn: "Kids Meal", price: 115, cat: "Kids", img: "/images/dining-scene.jpg", spicy: 0 },
];

const skeletonOffers = [
  { titleAr: "وجبات أطفال", titleEn: "Kids Meal", desc: "Crispy / Nugget / Chicken Burger / Beef Burger", price: "115", img: "/images/dining-scene.jpg", badge: "HOT" },
  { titleAr: "بوكس البرنس", titleEn: "Brens Box", desc: "Chicken strips + extras", price: "215", img: "/images/fried-basket.jpg", badge: "NEW" },
  { titleAr: "بوكس الهيرو", titleEn: "Hero Box", desc: "Mixed meal for the group", price: "195", img: "/images/chicken-plate.jpg", badge: "POPULAR" },
  { titleAr: "شاورما هالبينو", titleEn: "Jalapeno Shawarma", desc: "Spicy chicken shawarma sandwich", price: "55", img: "/images/grilled-skewers.jpg", badge: "NEW" },
  { titleAr: "عصائر طبيعية", titleEn: "Natural Juices", desc: "Mango 20 LE / Strawberry 15 LE / Orange 15 LE", price: "15", img: "/images/catering-spread.jpg", badge: "FRESH" },
];

export default function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const section2Ref = useRef<HTMLDivElement>(null);
  const section3Ref = useRef<HTMLDivElement>(null);
  const section4Ref = useRef<HTMLDivElement>(null);
  const section5Ref = useRef<HTMLDivElement>(null);
  const addItem = useCartStore((s) => s.addItem);

  // Fetch menu data
  const { data: categories, isLoading: catsLoading } = trpc.menu.categories.useQuery();
  const { data: menuItems, isLoading: itemsLoading } = trpc.menu.items.useQuery();

  // Get popular items for best sellers (first 6 popular or isNew items)
  const bestSellers = menuItems?.filter((item) => item.isPopular || item.isNew).slice(0, 6) || [];

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero entrance
      gsap.fromTo(".hero-collage",
        { x: -200, opacity: 0, rotate: -6 },
        { x: 0, opacity: 1, rotate: 0, duration: 1, ease: "power3.out" }
      );
      gsap.fromTo(".hero-badge",
        { scale: 0.2, rotate: -25 },
        { scale: 1, rotate: 0, duration: 0.7, ease: "back.out(1.8)", delay: 0.3 }
      );
      gsap.fromTo(".hero-headline",
        { x: 100, opacity: 0 },
        { x: 0, opacity: 1, duration: 0.9, ease: "power3.out", delay: 0.2 }
      );
      gsap.fromTo(".hero-cta",
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, delay: 0.6 }
      );

      // Scroll animations
      const sections = [section2Ref, section3Ref, section4Ref, section5Ref];
      sections.forEach((ref) => {
        if (!ref.current) return;
        gsap.fromTo(ref.current.querySelectorAll(".animate-in"),
          { y: 40, opacity: 0 },
          {
            y: 0, opacity: 1, duration: 0.8, stagger: 0.1,
            scrollTrigger: { trigger: ref.current, start: "top 80%", toggleActions: "play none none reverse" }
          }
        );
      });
    });

    return () => ctx.revert();
  }, []);

  const handleAddToCart = (item: typeof bestSellers[0]) => {
    addItem({
      menuItemId: item.id,
      name: item.nameEn,
      nameAr: item.nameAr,
      price: Number(item.price),
      quantity: 1,
    });
    toast.success(`Added ${item.nameAr} to cart`);
  };

  return (
    <div className="bg-brand-bg">
      {/* Section 1: Hero */}
      <section ref={heroRef} className="relative min-h-screen flex items-center overflow-hidden grid-overlay">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-bg via-brand-bg/95 to-brand-bg/80" />
        <div className="w-full px-6 lg:px-12 py-24 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left - Collage */}
            <div className="hero-collage relative">
              <div className="absolute -left-4 -top-4 w-24 h-64 bg-brand-accent rounded-2xl -rotate-6 opacity-60" />
              <div className="relative rounded-3xl overflow-hidden border-[10px] border-white shadow-2xl shadow-black/50">
                <img
                  src="/images/hero-kitchen.jpg"
                  alt="Chikno Kitchen"
                  className="w-full h-[50vh] lg:h-[60vh] object-cover"
                />
              </div>
              <div className="hero-badge absolute -right-4 top-8 w-20 h-20 lg:w-24 lg:h-24 rounded-full bg-brand-accent border-4 border-black flex items-center justify-center shadow-xl">
                <Flame className="w-8 h-8 lg:w-10 lg:h-10 text-black" />
              </div>
            </div>

            {/* Right - Content */}
            <div className="space-y-6">
              <h1
                className="hero-headline text-5xl lg:text-7xl xl:text-8xl font-black text-white leading-none tracking-tighter font-display"
              >
                CHICKEN<br />
                <span className="text-brand-accent">& MORE</span>
              </h1>
              <p className="text-lg lg:text-xl text-white/60 max-w-md">
                Crispy, grilled, sauced—served your way. The flavor that hits different.
              </p>
              <div className="hero-cta flex flex-wrap gap-4 pt-4">
                <Link
                  to="/menu"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-brand-accent text-black font-bold uppercase tracking-wide hover:scale-105 transition-transform shadow-lg shadow-brand-accent/20"
                >
                  Explore Menu <ChevronRight className="w-4 h-4" />
                </Link>
                <Link
                  to="/branches"
                  className="inline-flex items-center gap-2 px-8 py-4 rounded-full border-2 border-white/20 text-white font-semibold hover:bg-white/5 transition-colors"
                >
                  Find Location
                </Link>
              </div>
              <p className="text-sm text-white/30 pt-4">Fresh daily. Bold flavor. No compromises.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: Story + Categories */}
      <section ref={section2Ref} className="py-24 grid-overlay relative">
        <div className="w-full px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-16">
            {/* Left - Story */}
            <div className="space-y-6 animate-in">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-accent">Our Story</span>
              <h2 className="text-4xl lg:text-5xl font-black text-white font-display">
                Built on cravings.
              </h2>
              <p className="text-white/60 leading-relaxed">
                Chikno started as a late-night window and grew into a full-menu kitchen. 
                We focus on crispy chicken, fresh sides, and fast, friendly service—without the fluff.
              </p>
            </div>

            {/* Right - Categories */}
            <div className="space-y-6 animate-in">
              <h3 className="text-2xl font-bold text-white">What's on the menu</h3>
              <div className="grid grid-cols-2 gap-3">
                {catsLoading ? (
                  Array.from({ length: 6 }).map((_, i) => (
                    <Skeleton key={i} className="h-20 rounded-xl bg-white/5" />
                  ))
                ) : (
                  categories?.slice(0, 6).map((cat) => (
                    <Link
                      key={cat.id}
                      to={`/menu?cat=${cat.nameEn}`}
                      className="group flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/5 hover:bg-brand-accent/10 hover:border-brand-accent/30 transition-all"
                    >
                      <span className="text-2xl">{cat.icon || catIcons[cat.nameEn]}</span>
                      <div>
                        <p className="font-semibold text-sm text-white group-hover:text-brand-accent transition-colors">
                          <span lang="ar">{cat.nameAr}</span>
                        </p>
                        <p className="text-xs text-white/40">{cat.nameEn}</p>
                      </div>
                    </Link>
                  ))
                )}
              </div>
              <p className="text-xs text-white/30">Allergens? Ask the team—every location keeps a printed guide.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 3: Best Sellers */}
      <section ref={section3Ref} className="py-24 relative">
        <div className="w-full px-6 lg:px-12">
          <div className="flex items-center justify-between mb-12 animate-in">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-accent">Best Sellers</span>
              <h2 className="text-4xl lg:text-5xl font-black text-white mt-2 font-display">
                Most Ordered
              </h2>
            </div>
            <Link to="/menu" className="hidden md:flex items-center gap-2 text-sm text-brand-accent hover:underline">
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {itemsLoading ? (
              skeletonBestSellers.map((_, i) => (
                <Skeleton key={i} className="h-80 rounded-2xl bg-white/5" />
              ))
            ) : (
              (bestSellers.length > 0 ? bestSellers : skeletonBestSellers).map((item, i) => (
                <div key={i} className="animate-in group relative rounded-2xl overflow-hidden bg-white/[0.02] border border-white/5 hover:border-brand-accent/30 transition-all duration-300">
                  <div className="relative h-48 overflow-hidden">
                    {item.image && (
                      <img src={item.image} alt={item.nameEn} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    )}
                    <div className="absolute top-3 left-3">
                      <span className="px-3 py-1 rounded-full bg-brand-accent text-black text-xs font-bold">{item.categoryId}</span>
                    </div>
                    {item.isSpicy && (
                      <div className="absolute top-3 right-3 flex gap-0.5">
                        {Array.from({ length: item.spicyLevel || 1 }).map((_, j) => (
                          <Flame key={j} className="w-3 h-3 text-orange-500" />
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="p-5">
                    <h3 className="font-bold text-white text-lg">
                      <span lang="ar">{item.nameAr}</span>
                    </h3>
                    <p className="text-sm text-white/40">{item.nameEn}</p>
                    <div className="flex items-center justify-between mt-4">
                      <span className="text-xl font-black text-brand-accent">{item.price} LE</span>
                      <button
                        onClick={() => handleAddToCart(item)}
                        className="px-4 py-2 rounded-full bg-white/10 text-sm font-semibold hover:bg-brand-accent hover:text-black transition-all"
                      >
                        Add +
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Section 4: Signature Feature */}
      <section className="py-24 grid-overlay relative">
        <div className="w-full px-6 lg:px-12" ref={section4Ref}>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-in relative">
              <div className="absolute -left-4 -bottom-4 w-32 h-48 bg-brand-accent/20 rounded-2xl rotate-12" />
              <div className="relative rounded-3xl overflow-hidden border-[10px] border-white shadow-2xl">
                <img src="/images/chicken-plate.jpg" alt="Signature Chicken" className="w-full h-[50vh] object-cover" />
              </div>
              <div className="absolute -right-3 top-12 w-16 h-16 rounded-full bg-brand-accent border-4 border-black flex items-center justify-center">
                <Star className="w-6 h-6 text-black" />
              </div>
            </div>
            <div className="space-y-6 animate-in">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-accent">Signature</span>
              <h2 className="text-4xl lg:text-6xl font-black text-white font-display">
                SIGNATURE<br />CHICKEN
              </h2>
              <p className="text-white/60 text-lg leading-relaxed max-w-md">
                Brined, seasoned, and finished with a crunch that holds up from kitchen to couch. 
                Our signature recipe has been perfected over years.
              </p>
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-brand-accent text-black font-bold uppercase tracking-wide hover:scale-105 transition-transform"
              >
                See Chicken Options <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Section 5: Offers Carousel */}
      <section className="py-24 relative">
        <div className="w-full px-6 lg:px-12">
          <div className="text-center mb-12 animate-in">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-accent">Hot Deals</span>
            <h2 className="text-4xl lg:text-5xl font-black text-white mt-2 font-display">
              Current Offers
            </h2>
          </div>

          <div className="flex overflow-x-auto gap-6 pb-6 scrollbar-hide snap-x snap-mandatory" ref={section5Ref}>
            {skeletonOffers.map((offer, i) => (
              <div
                key={i}
                className="animate-in snap-start flex-shrink-0 w-[85vw] sm:w-[400px] rounded-2xl overflow-hidden bg-gradient-to-br from-[#1a1a2e] to-brand-bg border border-white/5 relative group"
              >
                <div className="relative h-48">
                  <img src={offer.img} alt={offer.titleEn} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-bg to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      offer.badge === "NEW" ? "bg-blue-500" :
                      offer.badge === "HOT" ? "bg-red-500" :
                      offer.badge === "POPULAR" ? "bg-purple-500" :
                      "bg-green-500"
                    } text-white`}>
                      {offer.badge}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white">
                    <span lang="ar">{offer.titleAr}</span>
                  </h3>
                  <p className="text-sm text-white/40">{offer.titleEn}</p>
                  <p className="text-sm text-white/50 mt-2">{offer.desc}</p>
                  <div className="flex items-center justify-between mt-4">
                    <span className="text-2xl font-black text-brand-accent">from {offer.price} LE</span>
                    <button
                      className="px-4 py-2 rounded-full bg-brand-accent text-black text-sm font-bold hover:scale-105 transition-transform"
                    >
                      Order
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 6: Visit / Location */}
      <section className="py-24 grid-overlay relative">
        <div className="w-full px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-in order-2 lg:order-1">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-accent">Visit Us</span>
              <h2 className="text-4xl lg:text-5xl font-black text-white font-display">
                VISIT CHIKNO
              </h2>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-brand-accent mt-0.5" />
                  <div>
                    <p className="font-semibold">279 Al-Matbaa Station St</p>
                    <p className="text-sm text-white/50">Faisal, Giza</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-brand-accent mt-0.5" />
                  <div>
                    <p className="text-sm text-white/60">Sun - Thu: 12pm - 12am</p>
                    <p className="text-sm text-white/60">Fri - Sat: 1pm - 1am</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <PhoneIcon />
                  <span className="text-sm text-white/60">+20 101 991 1122</span>
                </div>
              </div>
              <div className="flex flex-wrap gap-4 pt-4">
                <a
                  href="https://wa.me/201117655537"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-green-600 text-white font-semibold hover:scale-105 transition-transform"
                >
                  WhatsApp Order
                </a>
                <Link
                  to="/branches"
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/20 text-white font-semibold hover:bg-white/5 transition-colors"
                >
                  All Branches
                </Link>
              </div>
            </div>
            <div className="animate-in order-1 lg:order-2 relative">
              <div className="rounded-3xl overflow-hidden border-[10px] border-white shadow-2xl">
                <img src="/images/restaurant-interior.jpg" alt="Chikno Location" className="w-full h-[40vh] lg:h-[50vh] object-cover" />
              </div>
              <div className="absolute -bottom-4 -left-4 w-24 h-24 rounded-2xl bg-brand-accent flex items-center justify-center shadow-xl">
                <MapPin className="w-8 h-8 text-black" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 7: Rewards */}
      <section className="py-24 relative bg-[#E9F7FF]">
        <div className="w-full px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-in relative order-1">
              <div className="rounded-3xl overflow-hidden border-[10px] border-brand-bg shadow-2xl">
                <img src="/images/rewards-phone.jpg" alt="Chikno Rewards" className="w-full h-[40vh] lg:h-[50vh] object-cover" />
              </div>
            </div>
            <div className="space-y-6 animate-in order-2">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-bg/50">Loyalty Program</span>
              <h2 className="text-4xl lg:text-6xl font-black text-brand-bg font-display">
                CHIKNO<br />REWARDS
              </h2>
              <p className="text-brand-bg/60 text-lg leading-relaxed max-w-md">
                Earn points on every order. Every 10 LE spent = 1 point. 
                Redeem for free chicken, meals, and exclusive boxes.
              </p>
              <div className="space-y-2">
                <div className="flex items-center gap-3">
                  <Award className="w-5 h-5 text-brand-bg" />
                  <span className="text-brand-bg/80">100 pts = Free Crispy</span>
                </div>
                <div className="flex items-center gap-3">
                  <Award className="w-5 h-5 text-brand-bg" />
                  <span className="text-brand-bg/80">250 pts = Free Broasted Meal</span>
                </div>
                <div className="flex items-center gap-3">
                  <Award className="w-5 h-5 text-brand-bg" />
                  <span className="text-brand-bg/80">500 pts = Free Hero Box</span>
                </div>
              </div>
              <Link
                to="/loyalty"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-brand-bg text-white font-bold uppercase tracking-wide hover:scale-105 transition-transform"
              >
                Join the Club <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Section 8: Delivery */}
      <section className="py-24 grid-overlay relative">
        <div className="w-full px-6 lg:px-12">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-in">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-accent">Delivery</span>
              <h2 className="text-4xl lg:text-5xl font-black text-white font-display">
                GET IT<br />DELIVERED
              </h2>
              <p className="text-white/60 leading-relaxed max-w-md">
                Order through our website, call us directly, or pick up at the counter. 
                Fast delivery across Giza.
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                  <Truck className="w-5 h-5 text-brand-accent" />
                  <span className="text-white/80">Order via the app/website</span>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                  <PhoneIcon />
                  <span className="text-white/80">Call the branch</span>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5">
                  <UtensilsCrossed className="w-5 h-5 text-brand-accent" />
                  <span className="text-white/80">Pickup at the counter</span>
                </div>
              </div>
              <Link
                to="/menu"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-brand-accent text-black font-bold uppercase tracking-wide hover:scale-105 transition-transform"
              >
                Order Online <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
            <div className="animate-in relative">
              <div className="rounded-3xl overflow-hidden border-[10px] border-white shadow-2xl">
                <img src="/images/delivery-handoff.jpg" alt="Delivery" className="w-full h-[40vh] lg:h-[50vh] object-cover" />
              </div>
              <div className="absolute -top-4 -right-4 w-20 h-20 rounded-2xl bg-brand-accent flex items-center justify-center shadow-xl rotate-6">
                <Truck className="w-8 h-8 text-black" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 9: Reviews Marquee */}
      <section className="py-24 relative overflow-hidden">
        <div className="w-full px-6 lg:px-12 mb-12">
          <div className="text-center animate-in">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-accent">Testimonials</span>
            <h2 className="text-4xl lg:text-5xl font-black text-white mt-2 font-display">
              What People Say
            </h2>
          </div>
        </div>
        <div className="relative">
          <div className="flex gap-6 animate-marquee">
            {[...reviews, ...reviews].map((review, i) => (
              <div
                key={i}
                className="flex-shrink-0 w-[320px] p-6 rounded-2xl bg-white/[0.02] border border-white/5"
              >
                <div className="flex gap-1 mb-3">
                  {Array.from({ length: review.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-brand-accent fill-brand-accent" />
                  ))}
                </div>
                <p className="text-white/70 mb-4">"{review.text}"</p>
                <p className="text-sm text-white/40 font-semibold">— {review.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 10: Catering */}
      <section className="py-24 relative">
        <div className="w-full px-6 lg:px-12">
          <div className="relative rounded-3xl overflow-hidden">
            <img src="/images/catering-spread.jpg" alt="Catering" className="w-full h-[50vh] lg:h-[60vh] object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-brand-bg via-brand-bg/60 to-transparent" />
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8">
              <h2 className="text-4xl lg:text-7xl font-black text-white mb-4 font-display">
                CATERING
              </h2>
              <p className="text-white/70 text-lg max-w-md mb-8">
                Trays, boxes, and sides—made to feed a crew. Perfect for events, parties, and gatherings.
              </p>
              <Link
                to="/contact"
                className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-brand-accent text-black font-bold uppercase tracking-wide hover:scale-105 transition-transform"
              >
                Request Catering <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Section 11: AI Chat CTA */}
      <section className="py-16 border-t border-white/5">
        <div className="w-full px-6 lg:px-12">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-8 rounded-2xl bg-gradient-to-r from-brand-accent/10 to-transparent border border-brand-accent/20">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-full bg-brand-accent/20 flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-brand-accent" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white">Need Help Ordering?</h3>
                <p className="text-white/50">Chat with our AI assistant for recommendations</p>
              </div>
            </div>
            <Link
              to="/chat"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-brand-accent text-black font-bold hover:scale-105 transition-transform whitespace-nowrap"
            >
              Start Chatting <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

function PhoneIcon() {
  return (
    <svg className="w-5 h-5 text-brand-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
    </svg>
  );
}
