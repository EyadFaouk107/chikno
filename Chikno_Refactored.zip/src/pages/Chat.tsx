import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Sparkles, Trash2 } from "lucide-react";
import { trpc } from "@/providers/trpc";

function getSessionId() {
  let sid = sessionStorage.getItem("chat_session_id");
  if (!sid) {
    sid = `chat_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    sessionStorage.setItem("chat_session_id", sid);
  }
  return sid;
}

export default function Chat() {
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([
    { role: "assistant", content: "Hey there! Welcome to Chikno! I'm your AI assistant. I can help you with our menu, prices, ordering, locations, and more. What can I do for you today?" },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const sessionId = getSessionId();

  const chatMutation = trpc.chat.send.useMutation({
    onSuccess: (data) => {
      setMessages((prev) => [...prev, { role: "assistant", content: data.response }]);
      setIsTyping(false);
    },
    onError: () => {
      setMessages((prev) => [...prev, { role: "assistant", content: "Sorry, I'm having trouble connecting. Please try again later!" }]);
      setIsTyping(false);
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg = input.trim();
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setInput("");
    setIsTyping(true);
    chatMutation.mutate({ sessionId, message: userMsg });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = () => {
    setMessages([
      { role: "assistant", content: "Hey there! Welcome to Chikno! I'm your AI assistant. I can help you with our menu, prices, ordering, locations, and more. What can I do for you today?" },
    ]);
  };

  const quickQuestions = [
    "What's on the menu?",
    "How much is delivery?",
    "What are your hours?",
    "Spicy options?",
  ];

  return (
    <div className="min-h-screen bg-[#0B0C0F] pt-16 pb-16 flex flex-col">
      {/* Chat Header */}
      <div className="w-full px-6 lg:px-12 py-4 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-[#BFFF00]/20 flex items-center justify-center">
            <Bot className="w-5 h-5 text-[#BFFF00]" />
          </div>
          <div>
            <h1 className="font-bold text-white">Chikno AI Assistant</h1>
            <div className="flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#BFFF00]" />
              <span className="text-xs text-[#BFFF00]">Online</span>
            </div>
          </div>
        </div>
        <button
          onClick={clearChat}
          className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/5 text-sm text-white/60 hover:bg-white/10 transition-colors"
        >
          <Trash2 className="w-3 h-3" /> Clear
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 lg:px-12 py-6 space-y-4">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
              msg.role === "assistant" ? "bg-[#BFFF00]/20" : "bg-white/10"
            }`}>
              {msg.role === "assistant" ? (
                <Bot className="w-4 h-4 text-[#BFFF00]" />
              ) : (
                <User className="w-4 h-4 text-white" />
              )}
            </div>
            <div
              className={`max-w-[80%] lg:max-w-[60%] p-4 rounded-2xl text-sm leading-relaxed ${
                msg.role === "user"
                  ? "bg-[#BFFF00] text-black rounded-br-sm"
                  : "bg-white/5 text-white/80 rounded-bl-sm"
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-[#BFFF00]/20 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-[#BFFF00]" />
            </div>
            <div className="bg-white/5 p-4 rounded-2xl rounded-bl-sm">
              <div className="flex gap-1">
                <span className="w-2 h-2 rounded-full bg-white/30 animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 rounded-full bg-white/30 animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 rounded-full bg-white/30 animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Questions */}
      {messages.length <= 2 && (
        <div className="px-6 lg:px-12 pb-2">
          <div className="flex flex-wrap gap-2">
            {quickQuestions.map((q) => (
              <button
                key={q}
                onClick={() => {
                  setMessages((prev) => [...prev, { role: "user", content: q }]);
                  setIsTyping(true);
                  chatMutation.mutate({ sessionId, message: q });
                }}
                className="px-4 py-2 rounded-full bg-white/5 text-sm text-white/60 hover:bg-[#BFFF00]/10 hover:text-[#BFFF00] transition-colors border border-white/5"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input */}
      <div className="px-6 lg:px-12 py-4 border-t border-white/5">
        <div className="flex gap-3 max-w-3xl mx-auto">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask me anything about Chikno..."
            className="flex-1 px-5 py-3 rounded-full bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-[#BFFF00]/50"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isTyping}
            className="w-12 h-12 rounded-full bg-[#BFFF00] flex items-center justify-center hover:scale-105 transition-transform disabled:opacity-50 disabled:hover:scale-100"
          >
            <Send className="w-5 h-5 text-black" />
          </button>
        </div>
      </div>
    </div>
  );
}
