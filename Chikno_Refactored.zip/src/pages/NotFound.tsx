import { Link } from "react-router";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#0B0C0F] flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="text-8xl font-black text-[#BFFF00] mb-4" style={{ fontFamily: 'Montserrat' }}>
          404
        </h1>
        <p className="text-2xl font-bold text-white mb-2">Page Not Found</p>
        <p className="text-white/50 mb-8">The page you're looking for doesn't exist.</p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-[#BFFF00] text-black font-bold uppercase tracking-wide hover:scale-105 transition-transform"
        >
          <ArrowLeft className="w-4 h-4" /> Back to Home
        </Link>
      </div>
    </div>
  );
}
