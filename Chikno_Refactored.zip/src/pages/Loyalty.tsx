import { Award, Crown, Diamond, Star, ChevronRight } from "lucide-react";
import { Link } from "react-router";

const tiers = [
  { name: "Bronze", min: 0, color: "#CD7F32", icon: Star },
  { name: "Silver", min: 500, color: "#C0C0C0", icon: Award },
  { name: "Gold", min: 1500, color: "#FFD700", icon: Crown },
  { name: "Diamond", min: 5000, color: "#B9F2FF", icon: Diamond },
];

const rewards = [
  { points: 100, reward: "Free Crispy Sandwich", icon: "🥪" },
  { points: 250, reward: "Free Broasted Meal", icon: "🍗" },
  { points: 500, reward: "Free Hero Box", icon: "📦" },
];

export default function Loyalty() {
  const currentPoints = 0;
  const currentTier = tiers[0];
  const nextTier = tiers[1];
  const progress = (currentPoints / (nextTier?.min || 500)) * 100;

  return (
    <div className="min-h-screen bg-[#0B0C0F] pt-24 pb-24">
      <div className="w-full px-6 lg:px-12 max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#BFFF00]">Rewards</span>
          <h1 className="text-4xl lg:text-5xl font-black text-white mt-2" style={{ fontFamily: 'Montserrat' }}>
            CHIKNO REWARDS
          </h1>
          <p className="text-white/50 mt-3">Earn points with every order. Free chicken awaits!</p>
        </div>

        {/* Points Card */}
        <div className="p-8 rounded-3xl bg-gradient-to-br from-[#1a1a2e] to-[#0B0C0F] border border-white/5 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-sm text-white/40">Your Points</p>
              <p className="text-5xl font-black text-[#BFFF00]">{currentPoints}</p>
            </div>
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ backgroundColor: `${currentTier.color}20` }}>
              <Star className="w-8 h-8" style={{ color: currentTier.color }} />
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-white/60">{currentTier.name}</span>
              <span className="text-white/60">{nextTier?.name || "Max"}</span>
            </div>
            <div className="h-3 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#BFFF00] to-[#BFFF00]/70 transition-all duration-1000"
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>
            <p className="text-xs text-white/40 mt-2">
              {nextTier ? `${nextTier.min - currentPoints} points to ${nextTier.name}` : "You've reached the highest tier!"}
            </p>
          </div>

          <div className="text-center">
            <p className="text-sm text-white/40">Every 10 LE spent = 1 point</p>
          </div>
        </div>

        {/* Tiers */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {tiers.map((tier, i) => {
            const Icon = tier.icon;
            const isActive = currentPoints >= tier.min && (i === tiers.length - 1 || currentPoints < tiers[i + 1].min);
            const isUnlocked = currentPoints >= tier.min;

            return (
              <div
                key={tier.name}
                className={`p-4 rounded-2xl border text-center transition-all ${
                  isActive
                    ? "bg-[#BFFF00]/5 border-[#BFFF00]/30"
                    : isUnlocked
                    ? "bg-white/[0.02] border-white/10"
                    : "bg-white/[0.01] border-white/5 opacity-40"
                }`}
              >
                <div className={`w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center ${
                  isUnlocked ? "" : "bg-white/5"
                }`} style={{ backgroundColor: isUnlocked ? `${tier.color}20` : undefined }}>
                  <Icon className="w-6 h-6" style={{ color: isUnlocked ? tier.color : "#fff4" }} />
                </div>
                <p className={`font-bold text-sm ${isActive ? "text-[#BFFF00]" : "text-white"}`}>{tier.name}</p>
                <p className="text-xs text-white/40">{tier.min}+ pts</p>
              </div>
            );
          })}
        </div>

        {/* Rewards */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Redeem Rewards</h2>
          <div className="space-y-4">
            {rewards.map((reward) => (
              <div
                key={reward.points}
                className="flex items-center justify-between p-5 rounded-2xl bg-white/[0.02] border border-white/5"
              >
                <div className="flex items-center gap-4">
                  <span className="text-3xl">{reward.icon}</span>
                  <div>
                    <p className="font-semibold text-white">{reward.reward}</p>
                    <p className="text-sm text-white/40">{reward.points} points</p>
                  </div>
                </div>
                <button
                  disabled={currentPoints < reward.points}
                  className={`px-5 py-2 rounded-full text-sm font-semibold transition-all ${
                    currentPoints >= reward.points
                      ? "bg-[#BFFF00] text-black hover:scale-105"
                      : "bg-white/5 text-white/30 cursor-not-allowed"
                  }`}
                >
                  {currentPoints >= reward.points ? "Redeem" : "Locked"}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center">
          <p className="text-white/50 mb-4">Start earning points today!</p>
          <Link
            to="/menu"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-full bg-[#BFFF00] text-black font-bold uppercase tracking-wide hover:scale-105 transition-transform"
          >
            Place an Order <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}
