import { useState } from "react";
import { MapPin, Phone, Clock, Instagram, Facebook, Send, MessageCircle } from "lucide-react";
import { Link } from "react-router";

export default function Contact() {
  const [formData, setFormData] = useState({ name: "", phone: "", message: "" });

  const handleWhatsApp = () => {
    const text = `Hello Chikno! I'm ${formData.name || "a customer"}. ${formData.message}`;
    window.open(`https://wa.me/201117655537?text=${encodeURIComponent(text)}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-[#0B0C0F] pt-24 pb-24">
      <div className="w-full px-6 lg:px-12">
        <div className="text-center mb-12">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#BFFF00]">Get in Touch</span>
          <h1 className="text-4xl lg:text-5xl font-black text-white mt-2" style={{ fontFamily: 'Montserrat' }}>
            Contact Us
          </h1>
          <p className="text-white/50 mt-3">We'd love to hear from you</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Contact Info */}
          <div className="space-y-6">
            <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5">
              <h2 className="text-xl font-bold text-white mb-6">Contact Information</h2>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#BFFF00]/10 flex items-center justify-center shrink-0">
                    <MapPin className="w-4 h-4 text-[#BFFF00]" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">Address</p>
                    <p className="text-sm text-white/60">279 Al-Matbaa Station St, Faisal, Giza</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#BFFF00]/10 flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4 text-[#BFFF00]" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">Phone</p>
                    <p className="text-sm text-white/60">01019911122</p>
                    <p className="text-sm text-white/60">01117779975</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#BFFF00]/10 flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4 text-[#BFFF00]" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">Delivery</p>
                    <p className="text-sm text-white/60">01117655537</p>
                    <p className="text-sm text-white/60">01097711112</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#BFFF00]/10 flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4 text-[#BFFF00]" />
                  </div>
                  <div>
                    <p className="font-semibold text-white">Hours</p>
                    <p className="text-sm text-white/60">Sun-Thu: 12pm - 12am</p>
                    <p className="text-sm text-white/60">Fri-Sat: 1pm - 1am</p>
                  </div>
                </div>
              </div>
            </div>

            {/* WhatsApp CTA */}
            <a
              href="https://wa.me/201117655537?text=Hello%20Chikno!"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-6 rounded-2xl bg-green-600/10 border border-green-500/20 hover:bg-green-600/20 transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-green-600 flex items-center justify-center">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <div>
                <p className="font-bold text-green-400">Order via WhatsApp</p>
                <p className="text-sm text-green-400/60">01117655537 - Click to chat</p>
              </div>
            </a>

            {/* Social */}
            <div className="flex items-center gap-4">
              <a
                href="https://www.facebook.com/ChiknoEgypt"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-3 rounded-full bg-[#1877F2]/20 text-[#1877F2] font-semibold hover:bg-[#1877F2]/30 transition-colors"
              >
                <Facebook className="w-4 h-4" /> Facebook
              </a>
              <a
                href="https://www.instagram.com/ChiknoEgypt"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-5 py-3 rounded-full bg-[#E4405F]/20 text-[#E4405F] font-semibold hover:bg-[#E4405F]/30 transition-colors"
              >
                <Instagram className="w-4 h-4" /> Instagram
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5">
            <h2 className="text-xl font-bold text-white mb-6">Send us a Message</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-white/60 mb-2">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Your name"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-[#BFFF00]/50"
                />
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-2">Phone</label>
                <input
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="Your phone number"
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-[#BFFF00]/50"
                />
              </div>
              <div>
                <label className="block text-sm text-white/60 mb-2">Message</label>
                <textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Your message..."
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-[#BFFF00]/50 resize-none"
                />
              </div>
              <button
                onClick={handleWhatsApp}
                className="w-full flex items-center justify-center gap-2 px-6 py-4 rounded-xl bg-[#BFFF00] text-black font-bold uppercase tracking-wide hover:scale-[1.02] transition-transform"
              >
                <Send className="w-4 h-4" /> Send via WhatsApp
              </button>
            </div>
          </div>
        </div>

        {/* AI Chat CTA */}
        <div className="max-w-5xl mx-auto mt-12">
          <Link
            to="/chat"
            className="flex items-center justify-center gap-3 p-6 rounded-2xl bg-[#BFFF00]/5 border border-[#BFFF00]/20 hover:bg-[#BFFF00]/10 transition-colors text-center"
          >
            <MessageCircle className="w-6 h-6 text-[#BFFF00]" />
            <div>
              <p className="font-bold text-white">Need instant help?</p>
              <p className="text-sm text-white/60">Chat with our AI assistant for quick answers</p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}
