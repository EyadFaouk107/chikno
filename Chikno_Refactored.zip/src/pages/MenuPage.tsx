import { useState } from "react";
import { useSearchParams } from "react-router";
import { Search, Flame, Star, Sparkles } from "lucide-react";
import { trpc } from "@/providers/trpc";
import { useCartStore } from "@/hooks/useCartStore";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";

const catIcons: Record<string, string> = {
  "Fried Chicken": "🍗",
  "Grilled": "🔥",
  "Shawarma": "🌯",
  "Burgers & Sandwiches": "🍔",
  "Pizza": "🍕",
  "Boxes": "📦",
  "Fateh": "🍲",
  "Appetizers": "🥗",
  "Kids Meal": "👦",
  "Sweets": "🍮",
  "Drinks": "🥤",
  "Grilled Meat": "🥩",
};

export default function MenuPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState("");
  const [activeCat, setActiveCat] = useState<string | null>(searchParams.get("cat"));
  const [filter, setFilter] = useState<string>("all");
  const addItem = useCartStore((s) => s.addItem);

  const { data: categories, isLoading: catsLoading } = trpc.menu.categories.useQuery();
  const { data: menuItems, isLoading: itemsLoading } = trpc.menu.items.useQuery(
    activeCat ? { categoryId: categories?.find((c) => c.nameEn === activeCat || c.nameAr === activeCat)?.id } : undefined
  );

  const filteredItems = menuItems?.filter((item) => {
    const matchesSearch =
      !search ||
      item.nameAr.toLowerCase().includes(search.toLowerCase()) ||
      item.nameEn.toLowerCase().includes(search.toLowerCase());
    const matchesFilter =
      filter === "all" ||
      (filter === "spicy" && item.isSpicy) ||
      (filter === "new" && item.isNew) ||
      (filter === "popular" && item.isPopular);
    return matchesSearch && matchesFilter;
  });

  const handleAddToCart = (item: NonNullable<typeof menuItems>[0]) => {
    addItem({
      menuItemId: item.id,
      name: item.nameEn,
      nameAr: item.nameAr,
      price: Number(item.price),
      quantity: 1,
    });
    toast.success(`Added ${item.nameAr} to cart`);
  };

  return (
    <div className="min-h-screen bg-brand-bg pt-24 pb-24">
      <div className="w-full px-6 lg:px-12">
        {/* Header */}
        <div className="mb-8">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-accent">Our Menu</span>
          <h1 className="text-4xl lg:text-5xl font-black text-white mt-2 font-display">
            Full Menu
          </h1>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input
              type="text"
              placeholder="Search menu..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-11 pr-4 py-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-brand-accent/50"
            />
          </div>
          <div className="flex gap-2">
            {["all", "spicy", "new", "popular"].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-full text-sm font-semibold capitalize transition-all ${
                  filter === f
                    ? "bg-brand-accent text-black"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                {f === "spicy" && <Flame className="w-3 h-3 inline mr-1" />}
                {f === "new" && <Sparkles className="w-3 h-3 inline mr-1" />}
                {f === "popular" && <Star className="w-3 h-3 inline mr-1" />}
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex overflow-x-auto gap-2 pb-4 mb-8 scrollbar-hide">
          <button
            onClick={() => { setActiveCat(null); setSearchParams({}); }}
            className={`flex-shrink-0 px-5 py-2 rounded-full text-sm font-semibold transition-all ${
              !activeCat ? "bg-brand-accent text-black" : "bg-white/5 text-white/60 hover:bg-white/10"
            }`}
          >
            All
          </button>
          {catsLoading ? (
            Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="flex-shrink-0 w-24 h-9 rounded-full bg-white/5" />
            ))
          ) : (
            categories?.map((cat) => (
              <button
                key={cat.id}
                onClick={() => { setActiveCat(cat.nameEn); setSearchParams({ cat: cat.nameEn }); }}
                className={`flex-shrink-0 px-5 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-2 ${
                  activeCat === cat.nameEn || activeCat === cat.nameAr
                    ? "bg-brand-accent text-black"
                    : "bg-white/5 text-white/60 hover:bg-white/10"
                }`}
              >
                <span>{cat.icon || catIcons[cat.nameEn]}</span>
                {cat.nameEn}
              </button>
            ))
          )}
        </div>

        {/* Menu Grid */}
        {itemsLoading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array.from({ length: 12 }).map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-2xl bg-white/5" />
            ))}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredItems?.map((item) => (
              <div
                key={item.id}
                className="group p-5 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-brand-accent/30 transition-all duration-300"
              >
                {item.image && (
                  <img
                    src={item.image}
                    alt={item.nameEn}
                    className="w-full h-32 object-cover rounded-xl mb-3 group-hover:scale-105 transition-transform duration-300"
                  />
                )}
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-bold text-white text-base">
                        <span lang="ar">{item.nameAr}</span>
                      </h3>
                      {item.isNew && <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 text-[10px] font-bold">NEW</span>}
                      {item.isPopular && <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-400 text-[10px] font-bold">HOT</span>}
                    </div>
                    <p className="text-xs text-white/40">{item.nameEn}</p>
                  </div>
                </div>
                {item.isSpicy && (
                  <div className="flex items-center gap-1 mb-2">
                    {Array.from({ length: item.spicyLevel || 1 }).map((_, i) => (
                      <Flame key={i} className="w-3 h-3 text-orange-500" />
                    ))}
                    <span className="text-[10px] text-orange-400 ml-1">Spicy</span>
                  </div>
                )}
                <div className="flex items-center justify-between mt-4">
                  <div>
                    <span className="text-lg font-black text-brand-accent">{item.price} LE</span>
                    {item.priceLarge && (
                      <span className="text-xs text-white/30 ml-2">L: {item.priceLarge} LE</span>
                    )}
                  </div>
                  <button
                    onClick={() => handleAddToCart(item)}
                    className="px-4 py-2 rounded-full bg-white/10 text-sm font-semibold hover:bg-brand-accent hover:text-black transition-all"
                    aria-label="Add item to cart"
                  >
                    Add +
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {filteredItems?.length === 0 && !itemsLoading && (
          <div className="text-center py-16 text-white/40">
            <p className="text-lg">No items found</p>
            <p className="text-sm mt-2">Try adjusting your search or filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
