import { useState } from "react";
import { MapPin, Phone, Clock, Navigation, ExternalLink } from "lucide-react";

const branches = [
  {
    name: "Chikno Faisal - Main Branch",
    address: "279 Al-Matbaa Station St, Faisal, Giza",
    phone: "01019911122",
    phone2: "01117779975",
    delivery: "01117655537",
    whatsapp: "01117655537",
    hours: "Sun-Thu: 12pm-12am | Fri-Sat: 1pm-1am",
    status: "open",
    mapUrl: "https://www.google.com/maps/search/Chikno+Faisal+Giza",
  },
];

export default function Branches() {
  const [selectedBranch] = useState(0);

  return (
    <div className="min-h-screen bg-[#0B0C0F] pt-24 pb-24">
      <div className="w-full px-6 lg:px-12">
        <div className="text-center mb-12">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#BFFF00]">Locations</span>
          <h1 className="text-4xl lg:text-5xl font-black text-white mt-2" style={{ fontFamily: 'Montserrat' }}>
            Our Branches
          </h1>
          <p className="text-white/50 mt-3">Visit us at our locations across Egypt</p>
        </div>

        {/* Map Embed */}
        <div className="rounded-2xl overflow-hidden border border-white/5 mb-8">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3456.0!2d31.2!3d30.0!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzDCsDAwJzAwLjAiTiAzMcKwMTInMDAuMCJF!5e0!3m2!1sen!2seg!4v1"
            width="100%"
            height="400"
            style={{ border: 0, filter: "invert(90%) hue-rotate(180deg)" }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Chikno Location"
          />
        </div>

        {/* Branch Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {branches.map((branch, i) => (
            <div
              key={i}
              className={`p-6 rounded-2xl border transition-all ${
                selectedBranch === i
                  ? "bg-[#BFFF00]/5 border-[#BFFF00]/30"
                  : "bg-white/[0.02] border-white/5"
              }`}
            >
              <div className="flex items-start justify-between mb-4">
                <h3 className="font-bold text-white text-lg">{branch.name}</h3>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                  branch.status === "open" ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"
                }`}>
                  {branch.status === "open" ? "OPEN" : "CLOSED"}
                </span>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-[#BFFF00] mt-0.5 shrink-0" />
                  <span className="text-white/60">{branch.address}</span>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-4 h-4 text-[#BFFF00] mt-0.5 shrink-0" />
                  <span className="text-white/60">{branch.hours}</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-[#BFFF00] shrink-0" />
                  <span className="text-white/60">{branch.phone}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 mt-6">
                <a
                  href={`tel:${branch.phone}`}
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 text-sm font-semibold hover:bg-[#BFFF00]/20 transition-colors"
                >
                  <Phone className="w-3 h-3" /> Call
                </a>
                <a
                  href={`https://wa.me/${branch.whatsapp.replace(/^0/, '2')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-green-600/20 text-green-400 text-sm font-semibold hover:bg-green-600/30 transition-colors"
                >
                  <Phone className="w-3 h-3" /> WhatsApp
                </a>
                <a
                  href={branch.mapUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 text-sm font-semibold hover:bg-[#BFFF00]/20 transition-colors"
                >
                  <Navigation className="w-3 h-3" /> Directions
                </a>
                <a
                  href="/menu"
                  className="flex items-center gap-2 px-4 py-2 rounded-full bg-[#BFFF00] text-black text-sm font-semibold hover:scale-105 transition-transform"
                >
                  <ExternalLink className="w-3 h-3" /> Order
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
