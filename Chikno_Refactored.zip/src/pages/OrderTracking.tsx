import { useState } from "react";
import { Search, Check, Package, ChefHat, Truck, Home, Clock } from "lucide-react";
import { trpc } from "@/providers/trpc";

const statusSteps = [
  { key: "received", label: "Order Received", icon: Check },
  { key: "preparing", label: "Preparing", icon: Package },
  { key: "cooking", label: "In Kitchen", icon: ChefHat },
  { key: "ontheway", label: "On The Way", icon: Truck },
  { key: "delivered", label: "Delivered", icon: Home },
];

export default function OrderTracking() {
  const [orderNumber, setOrderNumber] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: order, isLoading, error } = trpc.order.track.useQuery(
    { orderNumber: searchQuery },
    { enabled: !!searchQuery }
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery(orderNumber.trim().toUpperCase());
  };

  const currentStepIndex = order
    ? statusSteps.findIndex((s) => s.key === order.status)
    : -1;

  return (
    <div className="min-h-screen bg-[#0B0C0F] pt-24 pb-24">
      <div className="w-full px-6 lg:px-12 max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#BFFF00]">Track</span>
          <h1 className="text-4xl lg:text-5xl font-black text-white mt-2" style={{ fontFamily: 'Montserrat' }}>
            Order Tracking
          </h1>
          <p className="text-white/50 mt-3">Enter your order number to track your delivery</p>
        </div>

        <form onSubmit={handleSearch} className="flex gap-3 mb-12">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <input
              type="text"
              placeholder="Enter order number (e.g., CHKABC123)"
              value={orderNumber}
              onChange={(e) => setOrderNumber(e.target.value)}
              className="w-full pl-11 pr-4 py-4 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/30 focus:outline-none focus:border-[#BFFF00]/50 uppercase"
            />
          </div>
          <button
            type="submit"
            className="px-8 py-4 rounded-xl bg-[#BFFF00] text-black font-bold uppercase tracking-wide hover:scale-105 transition-transform"
          >
            Track
          </button>
        </form>

        {isLoading && (
          <div className="text-center py-12">
            <div className="animate-spin w-8 h-8 border-2 border-[#BFFF00] border-t-transparent rounded-full mx-auto" />
          </div>
        )}

        {error && (
          <div className="text-center py-12 text-red-400">
            <p>Order not found. Please check your order number.</p>
          </div>
        )}

        {order && (
          <div className="space-y-8">
            {/* Order Info */}
            <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-white/40">Order Number</p>
                  <p className="text-xl font-bold text-white">{order.orderNumber}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-white/40">Status</p>
                  <span className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${
                    order.status === "delivered" ? "bg-green-500/20 text-green-400" :
                    order.status === "cancelled" ? "bg-red-500/20 text-red-400" :
                    "bg-[#BFFF00]/20 text-[#BFFF00]"
                  }`}>
                    {order.status.toUpperCase()}
                  </span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-white/40">Customer</p>
                  <p className="text-white">{order.customerName}</p>
                </div>
                <div>
                  <p className="text-white/40">Phone</p>
                  <p className="text-white">{order.customerPhone}</p>
                </div>
                <div>
                  <p className="text-white/40">Type</p>
                  <p className="text-white capitalize">{order.orderType}</p>
                </div>
                <div>
                  <p className="text-white/40">Total</p>
                  <p className="text-[#BFFF00] font-bold">{Number(order.total).toFixed(2)} LE</p>
                </div>
              </div>
            </div>

            {/* Progress Steps */}
            {order.status !== "cancelled" && (
              <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5">
                <div className="relative">
                  {/* Progress Line */}
                  <div className="absolute top-6 left-6 right-6 h-0.5 bg-white/10">
                    <div
                      className="h-full bg-[#BFFF00] transition-all duration-1000"
                      style={{ width: `${Math.max(0, (currentStepIndex / (statusSteps.length - 1)) * 100)}%` }}
                    />
                  </div>

                  <div className="flex justify-between relative z-10">
                    {statusSteps.map((step, i) => {
                      const Icon = step.icon;
                      const isCompleted = i <= currentStepIndex;
                      const isCurrent = i === currentStepIndex;

                      return (
                        <div key={step.key} className="flex flex-col items-center">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 transition-all duration-500 ${
                            isCompleted
                              ? "bg-[#BFFF00] border-[#BFFF00]"
                              : isCurrent
                              ? "bg-[#0B0C0F] border-[#BFFF00]"
                              : "bg-[#0B0C0F] border-white/10"
                          }`}>
                            <Icon className={`w-5 h-5 ${isCompleted ? "text-black" : isCurrent ? "text-[#BFFF00]" : "text-white/30"}`} />
                          </div>
                          <span className={`text-[10px] mt-2 font-semibold text-center max-w-[60px] ${
                            isCompleted ? "text-[#BFFF00]" : "text-white/30"
                          }`}>
                            {step.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Estimated Time */}
                <div className="mt-8 flex items-center gap-3 p-4 rounded-xl bg-[#BFFF00]/5 border border-[#BFFF00]/10">
                  <Clock className="w-5 h-5 text-[#BFFF00]" />
                  <div>
                    <p className="text-sm font-semibold text-white">Estimated Delivery</p>
                    <p className="text-sm text-white/60">30-45 minutes from order time</p>
                  </div>
                </div>
              </div>
            )}

            {/* Order Items */}
            <div className="p-6 rounded-2xl bg-white/[0.02] border border-white/5">
              <h3 className="font-bold text-white mb-4">Order Items</h3>
              <div className="space-y-3">
                {/* @ts-ignore */}
                {order.items?.map((item: any, i: number) => (
                  <div key={i} className="flex items-center justify-between py-2 border-b border-white/5">
                    <div>
                      <p className="text-white font-medium">{item.name}</p>
                      <p className="text-xs text-white/40">Qty: {item.quantity}</p>
                    </div>
                    <span className="text-[#BFFF00] font-semibold">{(Number(item.price) * item.quantity).toFixed(2)} LE</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
