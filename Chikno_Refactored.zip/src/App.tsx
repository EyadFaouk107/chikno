import { Routes, Route } from 'react-router'
import { lazy, Suspense } from 'react'
import { Toaster } from 'sonner'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import MobileNav from './components/MobileNav'
import PageLoader from './components/PageLoader'

const Home = lazy(() => import('./pages/Home'))
const MenuPage = lazy(() => import('./pages/MenuPage'))
const OrderTracking = lazy(() => import('./pages/OrderTracking'))
const Branches = lazy(() => import('./pages/Branches'))
const Loyalty = lazy(() => import('./pages/Loyalty'))
const Contact = lazy(() => import('./pages/Contact'))
const Chat = lazy(() => import('./pages/Chat'))
const Login = lazy(() => import('./pages/Login'))
const NotFound = lazy(() => import('./pages/NotFound'))

function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-brand-bg text-white">
      <Navbar />
      <main>{children}</main>
      <Footer />
      <MobileNav />
    </div>
  )
}

export default function App() {
  return (
    <>
      <Toaster position="top-center" richColors />
      <Routes>
        <Route element={<AppLayout><Suspense fallback={<PageLoader />}><Home /></Suspense></AppLayout>} path="/" />
      <Route element={<AppLayout><Suspense fallback={<PageLoader />}><MenuPage /></Suspense></AppLayout>} path="/menu" />
      <Route element={<AppLayout><Suspense fallback={<PageLoader />}><OrderTracking /></Suspense></AppLayout>} path="/track" />
      <Route element={<AppLayout><Suspense fallback={<PageLoader />}><Branches /></Suspense></AppLayout>} path="/branches" />
      <Route element={<AppLayout><Suspense fallback={<PageLoader />}><Loyalty /></Suspense></AppLayout>} path="/loyalty" />
      <Route element={<AppLayout><Suspense fallback={<PageLoader />}><Contact /></Suspense></AppLayout>} path="/contact" />
      <Route element={<AppLayout><Suspense fallback={<PageLoader />}><Chat /></Suspense></AppLayout>} path="/chat" />
      <Route path="/login" element={<Suspense fallback={<PageLoader />}><Login /></Suspense>} />
        <Route path="*" element={<Suspense fallback={<PageLoader />}><NotFound /></Suspense>} />
      </Routes>
    </>
  )
}
