import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter } from 'react-router'
import { ErrorBoundary } from 'react-error-boundary'
import './index.css'
import { TRPCProvider } from "@/providers/trpc"
import App from './App.tsx'
import CartDrawer from './components/CartDrawer.tsx'

function ErrorFallback() {
  return (
    <div className="min-h-screen bg-brand-bg flex items-center justify-center px-4">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-4">Something went wrong</h1>
        <p className="text-white/60 mb-8">Please refresh the page to try again.</p>
        <button
          onClick={() => window.location.reload()}
          className="px-6 py-3 rounded-full bg-brand-accent text-black font-bold hover:scale-105 transition-transform"
        >
          Refresh Page
        </button>
      </div>
    </div>
  )
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary FallbackComponent={ErrorFallback}>
      <BrowserRouter>
        <TRPCProvider>
          <App />
          <CartDrawer />
        </TRPCProvider>
      </BrowserRouter>
    </ErrorBoundary>
  </StrictMode>,
)
