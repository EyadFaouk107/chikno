import { getDb } from "../api/queries/connection";
import { categories, menuItems } from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding database...");

  // Insert categories
  const cats = [
    { nameEn: "Fried Chicken", nameAr: "فراخ مقلية", icon: "🍗", sortOrder: 1 },
    { nameEn: "Grilled", nameAr: "مشوي", icon: "🔥", sortOrder: 2 },
    { nameEn: "Shawarma", nameAr: "شاورما", icon: "🌯", sortOrder: 3 },
    { nameEn: "Burgers & Sandwiches", nameAr: "برجر وسندوتشات", icon: "🍔", sortOrder: 4 },
    { nameEn: "Pizza", nameAr: "بيتزا", icon: "🍕", sortOrder: 5 },
    { nameEn: "Boxes", nameAr: "بوكسات", icon: "📦", sortOrder: 6 },
    { nameEn: "Fateh", nameAr: "فتات", icon: "🍲", sortOrder: 7 },
    { nameEn: "Appetizers", nameAr: "مقبلات", icon: "🥗", sortOrder: 8 },
    { nameEn: "Kids Meal", nameAr: "وجبات أطفال", icon: "👦", sortOrder: 9 },
    { nameEn: "Sweets", nameAr: "حلويات", icon: "🍮", sortOrder: 10 },
    { nameEn: "Drinks", nameAr: "مشروبات", icon: "🥤", sortOrder: 11 },
    { nameEn: "Grilled Meat", nameAr: "مشويات لحوم", icon: "🥩", sortOrder: 12 },
  ];

  for (const cat of cats) {
    await db.insert(categories).values(cat).onDuplicateKeyUpdate({
      set: { nameEn: cat.nameEn, nameAr: cat.nameAr },
    });
  }
  console.log("Categories seeded");

  // Get category IDs
  const allCats = await db.select().from(categories);
  const catMap: Record<string, number> = {};
  for (const c of allCats) {
    catMap[c.nameEn] = c.id;
  }

  // Insert menu items - Fried Chicken
  const friedItems = [
    { nameAr: "3 قطع (صدر + جناح بروستد)", nameEn: "3 Pcs Broasted (Breast + Wing)", price: "130", isPopular: true },
    { nameAr: "3 قطع (فخد + دبوس + جناح)", nameEn: "3 Pcs Broasted (Thigh + Drumstick + Wing)", price: "140", isPopular: true },
    { nameAr: "3 قطع مقلية مع أرز", nameEn: "3 Pcs Fried with Rice", price: "175", isPopular: false },
    { nameAr: "5 قطع بروستد", nameEn: "5 Pcs Broasted", price: "190", isPopular: true },
    { nameAr: "6 قطع (فخد + دبوس + جناح دبل)", nameEn: "6 Pcs (Thigh + Drumstick + Wing Double)", price: "200", isPopular: false },
    { nameAr: "5 قطع دايبس مقلية بروستد", nameEn: "5 Pcs Dips Fried Broasted", price: "210", isPopular: false },
    { nameAr: "10 قطع بروستد", nameEn: "10 Pcs Broasted", price: "390", isPopular: false },
  ];

  for (const item of friedItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Fried Chicken"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
      isPopular: item.isPopular,
      isSpicy: false,
    });
  }

  // Cheetos Chicken
  const cheetosItems = [
    { nameAr: "3 قطع شيتوس", nameEn: "3 Pcs Cheetos Chicken", price: "130" },
    { nameAr: "3 قطع (صدر + جناح شيتوس)", nameEn: "3 Pcs Cheetos (Breast + Wing)", price: "145" },
    { nameAr: "6 قطع شيتوس", nameEn: "6 Pcs Cheetos Chicken", price: "200" },
    { nameAr: "5 قطع شيتوس مقلية", nameEn: "5 Pcs Cheetos Fried", price: "210" },
  ];

  for (const item of cheetosItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Fried Chicken"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
      isSpicy: false,
    });
  }

  // Grilled Chicken
  const grilledItems = [
    { nameAr: "وجبة ورك مشوي", nameEn: "Grilled Thigh Meal", price: "125" },
    { nameAr: "وجبة صدر مشوي", nameEn: "Grilled Breast Meal", price: "140" },
    { nameAr: "نصف فرخة مشوية", nameEn: "Half Grilled Chicken", price: "185" },
    { nameAr: "فرخة مشوية سادة", nameEn: "Whole Grilled Chicken", price: "300" },
  ];

  for (const item of grilledItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Grilled"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
      isPopular: false,
    });
  }

  // Shawarma
  const shawarmaItems = [
    { nameAr: "سندوتش شاورما كاكرز فراخ", nameEn: "Shawarma Kakars Chicken", price: "33", priceMedium: "43" },
    { nameAr: "سندوتش شاورما صاج فراخ", nameEn: "Shawarma Saj Chicken", price: "40", priceMedium: "50" },
    { nameAr: "سندوتش شاورما فرنساوي فراخ", nameEn: "French Shawarma Chicken", price: "45", priceMedium: "58" },
    { nameAr: "بوكس عربي دبل (6 قطعة) فراخ", nameEn: "Arabic Double Box (6pcs) Chicken", price: "110", priceMedium: "140" },
    { nameAr: "بوكس عربي دبل (12 قطعة) فراخ", nameEn: "Arabic Double Box (12pcs) Chicken", price: "150", priceMedium: "210" },
    { nameAr: "كيلو شاورما فراخ", nameEn: "1kg Shawarma Chicken", price: "300", priceMedium: "410" },
  ];

  for (const item of shawarmaItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Shawarma"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
      priceLarge: item.priceMedium,
      isPopular: true,
    });
  }

  // Jalapeno Shawarma (NEW)
  const jalapenoItems = [
    { nameAr: "سندوتش فراخ هالبينو", nameEn: "Jalapeno Chicken Sandwich", price: "55", isNew: true },
    { nameAr: "بوكس عربي فراخ هالبينو", nameEn: "Jalapeno Arabic Box Chicken", price: "75", isNew: true },
    { nameAr: "بوكس عربي دبل هالبينو", nameEn: "Jalapeno Arabic Double Box", price: "125", isNew: true },
    { nameAr: "بوكس عربي عالي هالبينو", nameEn: "Jalapeno Arabic High Box", price: "270", isNew: true },
  ];

  for (const item of jalapenoItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Shawarma"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
      isSpicy: true,
      spicyLevel: 2,
      isNew: item.isNew,
    });
  }

  // Fateh
  const fatehItems = [
    { nameAr: "فتة شاورما فراخ", nameEn: "Chicken Shawarma Fateh", price: "65", priceMedium: "85", isPopular: true },
    { nameAr: "فتة شاورما لحمة", nameEn: "Meat Shawarma Fateh", price: "70", priceMedium: "85" },
    { nameAr: "فتة شاورما مكس", nameEn: "Mixed Shawarma Fateh", price: "60", priceMedium: "95" },
    { nameAr: "فتة مكسيكانو", nameEn: "Mexicano Fateh", price: "63", priceMedium: "80" },
    { nameAr: "فتة كريسبي", nameEn: "Crispy Fateh", price: "47", priceMedium: "80" },
  ];

  for (const item of fatehItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Fateh"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
      priceLarge: item.priceMedium,
      isPopular: item.isPopular || false,
    });
  }

  // Sandwiches
  const sandwichItems = [
    { nameAr: "كريسبي", nameEn: "Crispy", price: "32", priceMedium: "55", isPopular: true },
    { nameAr: "زنجر", nameEn: "Zinger", price: "32", priceMedium: "55" },
    { nameAr: "سبايسي", nameEn: "Spicy", price: "32", priceMedium: "55", isSpicy: true, spicyLevel: 2 },
    { nameAr: "ناجيت", nameEn: "Nugget", price: "32", priceMedium: "55" },
    { nameAr: "سكالوب", nameEn: "Scallop", price: "32", priceMedium: "55" },
    { nameAr: "سوبريم", nameEn: "Supreme", price: "35", priceMedium: "60" },
    { nameAr: "ماجنوم", nameEn: "Magnum", price: "35", priceMedium: "60" },
    { nameAr: "كرانشي", nameEn: "Crunchy", price: "35", priceMedium: "60" },
    { nameAr: "تشكن رول", nameEn: "Chicken Roll", price: "35", priceMedium: "60" },
    { nameAr: "تويستر", nameEn: "Twister", price: "35", priceMedium: "60" },
    { nameAr: "شيش طاووق", nameEn: "Shish Tawook", price: "32", priceMedium: "55" },
    { nameAr: "مكسيكانو", nameEn: "Mexicano", price: "32", priceMedium: "55", isSpicy: true, spicyLevel: 1 },
    { nameAr: "فاهيتا دجاج", nameEn: "Chicken Fajita", price: "32", priceMedium: "55", isSpicy: true, spicyLevel: 1 },
    { nameAr: "فرانشيسكو", nameEn: "Francisco", price: "32", priceMedium: "55" },
    { nameAr: "نابولي", nameEn: "Napoli (NEW)", price: "35", priceMedium: "55", isNew: true },
    { nameAr: "نابولي دبل", nameEn: "Napoli Double (NEW)", price: "50", priceMedium: null, isNew: true },
    { nameAr: "تورينو", nameEn: "Torino (NEW)", price: "35", priceMedium: null, isNew: true },
    { nameAr: "كوردون بلو دجاج", nameEn: "Chicken Cordon Bleu", price: "45", priceMedium: "80" },
    { nameAr: "شرحات دجاج مع الجبنة", nameEn: "Chicken Strips with Cheese", price: "50", priceMedium: "90" },
    { nameAr: "فيلية تشيز ستيك لحمة", nameEn: "Philly Cheese Steak", price: "37", priceMedium: null },
    { nameAr: "برجر لحمة", nameEn: "Beef Burger", price: "32", priceMedium: "80" },
    { nameAr: "تشكن برجر", nameEn: "Chicken Burger", price: "27", priceMedium: "50" },
  ];

  for (const item of sandwichItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Burgers & Sandwiches"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
      priceLarge: item.priceMedium,
      isPopular: item.isPopular || false,
      isSpicy: item.isSpicy || false,
      spicyLevel: item.spicyLevel || 0,
      isNew: item.isNew || false,
    });
  }

  // Pizza
  const pizzaNames = [
    "Margherita", "Four Season", "Quattro Formaggi", "Jalapeno", "Axas",
    "Al-Mack", "Cheesy Cream", "Smoky Cream", "Al-Onion", "Chikno",
    "Shawarma Pizza", "Salami Pizza", "Super Supreme", "Smoky Turkey",
    "Sour Season", "Mac Greens", "Sour Pepperoni", "Mushroom Pizza"
  ];

  const pizzaArNames = [
    "مارجريتا", "فور سيزون", "كواترو فروماجي", "هالبينو", "أكساس",
    "المك", "شيبزي كريم", "كريمي مدخن", "الاونيون", "تشيكنو",
    "بيتزا شاورما", "بيتزا سلامي", "سوبر سوريم", "سموك تركي",
    "سور سيزون", "ماك جرينا", "سور بيبروني", "بيتزا مشروم"
  ];

  for (let i = 0; i < pizzaNames.length; i++) {
    await db.insert(menuItems).values({
      categoryId: catMap["Pizza"],
      nameAr: pizzaArNames[i],
      nameEn: pizzaNames[i],
      price: "95",
      priceMedium: "135",
      priceLarge: "185",
      isPopular: i >= 8,
    });
  }

  // Boxes
  const boxItems = [
    { nameAr: "بوكس الكيبح", nameEn: "Kabeh Box", price: "205" },
    { nameAr: "بوكس بروستي", nameEn: "Brosty Box", price: "195" },
    { nameAr: "بوكس التركي", nameEn: "Turkey Box", price: "260" },
    { nameAr: "بوكس الهيرو", nameEn: "Hero Box", price: "115", isPopular: true },
    { nameAr: "BBQ بوكس", nameEn: "BBQ Box", price: "240" },
    { nameAr: "Meat Kufta Box", nameEn: "Meat Kufta Box (NEW)", price: "205", isNew: true },
    { nameAr: "Chicken Kufta Box", nameEn: "Chicken Kufta Box (NEW)", price: "165", isNew: true },
    { nameAr: "بوكس البرنس", nameEn: "Brens Box (NEW)", price: "215", isNew: true },
    { nameAr: "Mix Kufta Box", nameEn: "Mix Kufta Box (NEW)", price: "190", isNew: true },
    { nameAr: "Calser 6 Box", nameEn: "Calser 6 Box", price: "280" },
    { nameAr: "Brosty Box 12pcs", nameEn: "Brosty Box 12pcs", price: "280" },
    { nameAr: "BBQ Box Large", nameEn: "BBQ Box Large", price: "315" },
    { nameAr: "بوكس البركة", nameEn: "Barkeh Box", price: "490" },
    { nameAr: "Hero Box Large", nameEn: "Hero Box Large", price: "195" },
    { nameAr: "King Box", nameEn: "King Box", price: "315" },
    { nameAr: "Turkey Box Large", nameEn: "Turkey Box Large", price: "345" },
  ];

  for (const item of boxItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Boxes"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
      isPopular: item.isPopular || false,
      isNew: item.isNew || false,
    });
  }

  // Grilled Meat
  const meatItems = [
    { nameAr: "وجبة مشاوي مكس", nameEn: "Mixed Grills Meal", price: "135" },
    { nameAr: "وجبة مشاوي مشكل", nameEn: "Assorted Grills Meal", price: "135" },
    { nameAr: "وجبة كباب شامي + أرز", nameEn: "Shami Kebab + Rice", price: "120" },
    { nameAr: "وجبة شف (كباب)", nameEn: "Chef Kebab Meal", price: "150" },
    { nameAr: "كيلو مشاوي مشكل", nameEn: "1kg Mixed Grills", price: "400" },
    { nameAr: "كيلو كباب شامي (كفتة)", nameEn: "1kg Shami Kebab (Kofta)", price: "460" },
    { nameAr: "رغيف عرايس", nameEn: "Arais Bread", price: "65" },
    { nameAr: "رغيف توشكا", nameEn: "Toshka Bread", price: "70" },
    { nameAr: "سندوتش كباب شامي", nameEn: "Shami Kebab Sandwich", price: "65" },
  ];

  for (const item of meatItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Grilled Meat"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
    });
  }

  // Appetizers
  const appetizerItems = [
    { nameAr: "سلطة خضراء", nameEn: "Green Salad", price: "40" },
    { nameAr: "بابا غنوج", nameEn: "Baba Ghanoush", price: "40" },
    { nameAr: "تبولة", nameEn: "Tabbouleh", price: "25" },
    { nameAr: "فتوش", nameEn: "Fattoush", price: "25" },
    { nameAr: "كول سلو", nameEn: "Coleslaw", price: "35" },
    { nameAr: "منيل", nameEn: "Munael", price: "45" },
    { nameAr: "كريم توم سبايسي", nameEn: "Spicy Garlic Cream", price: "5" },
    { nameAr: "فرص كبة مقلية", nameEn: "Fried Kubeh", price: "35" },
    { nameAr: "فرص كبة مشوية", nameEn: "Grilled Kubeh", price: "35" },
    { nameAr: "طق بطاطس", nameEn: "Potatoes Tag", price: "35" },
    { nameAr: "طق بطاطس شيبز", nameEn: "Chips Potatoes Tag", price: "47" },
    { nameAr: "طق أرز", nameEn: "Rice Tag", price: "35" },
    { nameAr: "ملوخية ساخنة", nameEn: "Hot Molokhia", price: "35" },
    { nameAr: "برك لحمة 4 قطعة", nameEn: "Meat Borek 4pcs", price: "12" },
    { nameAr: "برك جبنة 4 قطعة", nameEn: "Cheese Borek 4pcs", price: "14" },
    { nameAr: "حمص بالطحينية", nameEn: "Hummus with Tahini", price: "24" },
    { nameAr: "طراطور (طحينية)", nameEn: "Taratour (Tahini)", price: "24" },
    { nameAr: "مايوريز سبايسي", nameEn: "Spicy Mayo", price: "24" },
  ];

  for (const item of appetizerItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Appetizers"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
    });
  }

  // Kids Meal
  const kidsItems = [
    { nameAr: "كريسبي", nameEn: "Crispy Kids Meal", price: "115" },
    { nameAr: "ناجيت", nameEn: "Nugget Kids Meal", price: "115" },
    { nameAr: "تشكن برجر", nameEn: "Chicken Burger Kids Meal", price: "115" },
    { nameAr: "بيف برجر", nameEn: "Beef Burger Kids Meal", price: "125" },
  ];

  for (const item of kidsItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Kids Meal"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
    });
  }

  // Sweets
  const sweetItems = [
    { nameAr: "طق كنافة", nameEn: "Kunafa Tag", price: "35" },
    { nameAr: "ربع كيلو كنافة", nameEn: "1/4kg Kunafa", price: "45" },
    { nameAr: "نص كيلو كنافة", nameEn: "1/2kg Kunafa", price: "65" },
    { nameAr: "كيلو كنافة", nameEn: "1kg Kunafa", price: "120" },
  ];

  for (const item of sweetItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Sweets"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
    });
  }

  // Drinks
  const drinkItems = [
    { nameAr: "عصير مانجو طبيعي (250ml)", nameEn: "Natural Mango Juice (250ml)", price: "20" },
    { nameAr: "عصير فراولة (250ml)", nameEn: "Strawberry Juice (250ml)", price: "15" },
    { nameAr: "عصير برتقال (250ml)", nameEn: "Orange Juice (250ml)", price: "15" },
    { nameAr: "جلاب (250ml)", nameEn: "Jallab (250ml)", price: "10" },
    { nameAr: "مياه صغيرة", nameEn: "Small Water", price: "5" },
    { nameAr: "مياه كبيرة", nameEn: "Large Water", price: "7" },
    { nameAr: "كانز (بأنواعه)", nameEn: "Canned Soda", price: "8" },
  ];

  for (const item of drinkItems) {
    await db.insert(menuItems).values({
      categoryId: catMap["Drinks"],
      nameAr: item.nameAr,
      nameEn: item.nameEn,
      price: item.price,
    });
  }

  console.log("All menu items seeded successfully!");
}

seed().catch(console.error);
